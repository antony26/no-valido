# Tarea 2

## Sumario

Ejercicios de la pagina https://algo3.uqbar-project.org/gua-prctica-de-ejercicios/ejercicios-binding